/*Crear un programa que gestione el listado de celulares que estan a la venta. 
Para ello crear una estructura "celular", en la cual contenga los siguientes datos: 
codigo, marca, precio_lista, precio_publico, stock. 
Luego, crear un vector de estructuras del tipo celular de tama�o 3. 
Cargar los datos por defecto al vector.

Codigo	Marca	Precio_lista	Precio_publico	stock
1	Apple	1000	0	3
2	Samsung	600	0	0
3	Nokia	300	0	4
Crear un menu que permita las opciones: 
a. mostrar el listado completo de celulares
b. mostrar el listado completo de celulares que no hay stock. Y generar un archivo 
   para enviar al proveedor.
c. calcular_precio_publico. El precio al publico es una 30% mas del precio de lista.
d. ordenar por precio publico

*/


#include <iostream>
#include <string>
#include <fstream>

using namespace std;



struct Celular{
	int codigo;
	string marca;
	float precio_lista;
	float precio_publico;
	int stock;
};

void mostrar_listado(Celular *);
void mostrar_listado(Celular*, Celular [3]);
void sin_stock(Celular *);
void calcular_precio_publico(Celular *);
void ordenar_precio_publico(Celular *);
void ordenar_quickSort(Celular*, int, int);

int main(int argc, char *argv[]) {
	
	Celular listaCelular[3] = {{1,"Apple",1000,0,3},{2,"Samsung",300,0,0},{3,"Nokia",600,0,4}};
	Celular *ptr_listaCelular=listaCelular; //para el mostrar 2da forma
	
	char op = ' ';
	
	do{
		cout<<"----------------------------------------"<<endl;
		cout<<"MENU\na. Mostrar lista completa\nb. Lista sin stock\nc. Calcular precio publico\nd. Ordenado por precio al publico\nIngrese una opcion: "<<endl;
		cin>>op;
		cout<<"----------------------------------------"<<endl;
		switch (op) {
		case 'a':
		case 'A':
		{
			cout<<"\nLISTADO COMPLETO"<<endl;
			mostrar_listado(listaCelular);
			mostrar_listado(ptr_listaCelular, listaCelular);
			break;
		}
		case 'b':
		case 'B':
		{
			sin_stock(listaCelular);
			break;
		}
		case 'c':
		case 'C':
		{
			calcular_precio_publico (listaCelular);
			mostrar_listado(listaCelular);
			break;
		}
		case 'd':
		case 'D': 
		{
			ordenar_precio_publico(listaCelular);
			// con el metodo quick sort
			cout<<"ORDENADO - METODO ORDENAR QUICKSORT"<<endl;
			ordenar_quickSort(listaCelular, 3-1, 0);
			mostrar_listado(listaCelular);
			break;
		}
		default:
			cout<<"Ingrese una opcion valida"<<endl;
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	} while (op=='s' || op=='S');
	
	return 0;
}

void mostrar_listado(Celular *listaCelular){
	cout<<"\nCod.\tMarca\tP.L.\tP.P\tStock"<<endl;
	for(int i=0;i<3;i++){
		cout<<listaCelular[i].codigo<<"\t"<<listaCelular[i].marca<<"\t"<<listaCelular[i].precio_lista<<"\t"<<listaCelular[i].precio_publico<<"\t"<<listaCelular[i].stock<<endl;
	}
	cout<<endl;	
}
//otra manera de realizar el mostrar.
void mostrar_listado(Celular *ptr_listaCelular, Celular listaCelular[3]){
	cout<<"\nCod.\tMarca\tP.L.\tP.P\tStock"<<endl;
	for(int i=0;i<3;i++){
		ptr_listaCelular=&listaCelular[i];
		cout<<ptr_listaCelular->codigo<<"\t"<<ptr_listaCelular->marca<<"\t"<<ptr_listaCelular->precio_lista<<"\t"<<ptr_listaCelular->precio_publico<<"\t"<<ptr_listaCelular->stock<<endl;
	}
	cout<<endl;	
}

void sin_stock(Celular *listaCelular){
	ofstream ofs;
	ofs.open("Pedido_Proveedores.txt");
	ofs<<"Cod.\tMarca"<<endl;
	for(int i=0;i<3;i++){
		if(listaCelular[i].stock==0){
			ofs<<listaCelular[i].codigo<<"\t"<<listaCelular[i].marca;
		}
	}
	ofs.close();
	//Muestro el archivo por pantalla
	cout<<"\nARCHIVO GENERADO\n"<<endl;
	string mensaje;
	ifstream ifs;
	ifs.open("Pedido_Proveedores.txt");
	while(!ifs.eof()){
		getline(ifs,mensaje);
		cout<<mensaje<<endl;
	}
	ifs.close();
	cout<<endl;
}

void calcular_precio_publico(Celular *listaCelular){
	for(int i=0;i<3;i++){
		listaCelular[i].precio_publico=listaCelular[i].precio_lista*1.30;
	}
}

//metodo burbuja
void ordenar_precio_publico(Celular *listaCelular){
	cout<<"\nLISTADO ORDENADO POR PRECIO PUBLICO - ASCENDENTE"<<endl;
	Celular aux;
	for (int i = 0; i < 3; i++) //3 es el tama�o del vector
	{
		for (int j = 0; j < 2; j++) // 2 es el tama�o del vector - 1
		{
			if(listaCelular[j+1].precio_publico < listaCelular[j].precio_publico){
				aux = listaCelular[j];
				listaCelular[j] = listaCelular[j+1];
				listaCelular[j+1]=aux;
			}
		}
	}
	mostrar_listado(listaCelular);
	cout<<"\nLISTADO ORDENADO POR PRECIO PUBLICO - DESCENDENTE"<<endl;
	for (int i=0; i<3; i++) { 
		for (int j=0 ; j<2; j++) { 
			if (listaCelular[j].precio_publico < listaCelular[j+1].precio_publico) {
				aux = listaCelular[j+1];
				listaCelular[j+1] = listaCelular[j];
				listaCelular[j] = aux;
			}
		}
	}
	mostrar_listado(listaCelular);
}
//metodo quick sort
void ordenar_quickSort(Celular *listaCelular, int rl, int ll){
	Celular aux; //Creamos una estructura auxiliar para hacer los cambios.
	int izq=ll;
	int der=rl;
	int pivot=listaCelular[(ll+rl)/2].precio_publico;
	do{
		while (listaCelular[izq].precio_publico < pivot && izq < rl){ // Como se va ordenar por precio, se hace la comparacion con .precio_publico
			izq++;
		}
		while (listaCelular[der].precio_publico>pivot && der > ll){
			der--;
		}
		if(izq<=der){ // Una vez que se sabe quien es menor o mayor, se realizan los cambios directamente con la estructura
			aux = listaCelular[izq];
			listaCelular[izq]=listaCelular[der];
			listaCelular[der]=aux;
			izq++;
			der--;
		}
	} while(izq<=der);
	if(ll<der){
		ordenar_quickSort(listaCelular,der,ll);
	}
	if(rl>izq){
		ordenar_quickSort(listaCelular,rl,izq);
	}
}
