/* Escribir un programa utilizando punteros y funciones en la cual se desea cargar en un vector 
de tama�o 5. Rellenar con valores aleatorios entre 1 y 10. Luego crear un menu de opciones con 
las siguientes llamadas a funciones:
a. Mostrar los valores y direcciones de memoria.
b. Buscar y mostrar el numero menor y el numero mayor.
c. Calcular la suma de los valores pares.
*/
#include <iostream>
#include <ctime>

using namespace std;

void cargar_valores(int *);
void mostrar(int *);
int buscar_minimo(int *);
int buscar_maximo(int *);
int sumar_pares(int *);

int main(int argc, char *argv[]) {
	int v[5];
	int *ptr_v = v;
	cargar_valores(ptr_v);
	char op = ' ';
	do{
		cout<<"----------------------------------------"<<endl;
		cout<<"MENU\na. Mostrar valores y direcciones\nb. Minimo y Mayor\nc. Sumatoria de pares\nIngrese una opcion: "<<endl;
		cin>>op;
		cout<<"----------------------------------------"<<endl;
		switch (op) {
		case 'a':
		case 'A':
		{
			cout<<"\nLISTADO COMPLETO"<<endl;
			mostrar(ptr_v);
			break;
		}
		case 'b':
		case 'B':
		{
			cout<<"Valor minimo: "<<buscar_minimo(ptr_v)<<endl;
			cout<<"Valor maximo: "<<buscar_maximo(ptr_v)<<endl;
			break;
		}
		case 'c':
		case 'C':
		{
			cout<<"Suma de valores pares: "<<sumar_pares(ptr_v)<<endl;
			break;
		}
		default:
			cout<<"Ingrese una opcion valida"<<endl;
		}
		cout<<"\n�Desea seguir (S/N)? ";
		cin>>op;
	} while (op=='s' || op=='S');
	return 0;
}

void cargar_valores(int *ptr_v){
	int n = 0;
	srand(time(NULL));
	for (int i = 0; i < 5; i++) {
		n = rand()%10+1;
		ptr_v[i] = n;
	}
}

void mostrar(int *ptr_v){
	cout<<"Valor\tDireccion"<<endl;
	for(int i = 0; i < 5; i++){
		cout<<ptr_v[i]<<"\t"<<&ptr_v[i]<<endl;
	}
	cout<<endl;
}

int buscar_minimo(int *ptr_v){
	int min = 0;
	for(int i = 0; i < 5; i++){
		if(i==0){
			min=ptr_v[i];
		}else{
			if(min>ptr_v[i]){
				min=ptr_v[i];
			}
		}
	}
	return min;
}

int buscar_maximo(int *ptr_v){
	int max = 0;
	for(int i = 0; i < 5; i++){
		if(i==0){
			max=ptr_v[i];
		}else{
			if(max<ptr_v[i]){
				max=ptr_v[i];
			}
		}
	}
	return max;
}

int sumar_pares(int *ptr_v){
	int suma=0;
	for(int i = 0; i < 5; i++){
		if(ptr_v[i]%2==0){
			suma=suma+ptr_v[i];
		}
	}
	return suma;
}
